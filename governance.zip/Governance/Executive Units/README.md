# Executive Units
- The executive Units are in ministries traditional Governance. 
- Executives would be ministers in traditional governance.
- In this model there would be no head of ministers/prime minister or a president. but instead a set of executives elected individually. For more details on how they are elected refer to Governance.Executives
