# Governance
This repo is an attempt to build a governance system for alpha citizens.
It should give more power to the people and make a more fair, efficient, reliable, trustless and transparent system.
